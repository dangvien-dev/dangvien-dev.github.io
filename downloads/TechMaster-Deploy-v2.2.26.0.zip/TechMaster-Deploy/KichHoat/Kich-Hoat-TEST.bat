@echo off
:: CHAY THU quy trinh QR + gui Confirmation ID qua LAN bang ma gia. KHONG thay doi license.
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Kich-Hoat.ps1" -Product Windows -Test
